# Author: Maxwell Light
# Email: maxwell.light238@myci.csuci.edu
# Date: 03-05-21
# client.py - a simple client

import argparse, socket, logging, time, sys
import TicTacToeEngine
import TicTacToeProtocol

# Comment out the line below to not print the INFO messages
logging.basicConfig(level=logging.INFO)
ttte = TicTacToeEngine.TicTacToeEngine()
tttp = TicTacToeProtocol.TTTProtocol()


class Client:
    def __init__(self, host, port):
        # connect
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        self.sock.setblocking(True)
        self.playerSymbol = '-'
        self.isReady = False
        logging.info('Connecting to server: ' + host + ' on port: ' + str(port))

        self.get_player_symbol()
        self.set_player_ready_status()

        while True:
            # Manage player Turn
            self.sock.send(tttp.player_turn_packet())
            turnStatus = self.wait_for_turn_ack()
            while turnStatus == "not your turn":
                turnStatus = self.wait_for_turn_ack()
                continue
            if turnStatus == "end game":
                self.end_game()
                continue

            # Update the board from a request
            self.update_map()

            if self.check_if_game_over():
                self.set_player_ready_status()
                continue

            # Manage player input action
            print(f"It is your turn. Input a number 1-9 to place {self.playerSymbol}.")
            self.send_player_input_position()
            while self.wait_for_turn_action() != "executed move":
                continue

            # Update the board from a request
            self.update_map()

            if self.check_if_game_over():
                self.set_player_ready_status()
                continue
            print("Waiting for opponent's turn.")

            continue

        # quit
        self.sock.close()

    def get_player_symbol(self):
        self.sock.send(tttp.player_symbol_request_packet())
        while not self.wait_for_symbol_assign():
            continue

    def set_player_ready_status(self):
        self.sock.send(tttp.game_ready_to_start_packet())
        while self.wait_for_game_start() != "starting game":
            continue

    def update_map(self):
        self.sock.send(tttp.request_updated_board())
        while not self.wait_for_board_update():
            continue

    def check_if_game_over(self):
        self.sock.send(tttp.game_end_packet())
        if self.wait_for_game_end() == "game end":
            self.end_game()
            return True
        return False

    def end_game(self):
        print('=' * 40)
        winner = ttte.is_game_over()
        if winner != 'T':
            print(f"The Winner is {winner}!")
        else:
            print("Draw!")
        print("Restarting Game...")
        self.isReady = False
        ttte.restart()

    def recv_message(self):
        message = self.sock.recv(1024)
        if not message:
            raise EOFError('socket closed')
        return message

    # Waiting method until a message is received assigning this client's symbol (X or O)
    def wait_for_symbol_assign(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['player symbol']:
                # Send message to this client that it is waiting to start
                if not self.isReady:
                    print("Waiting for player...")
                # Ack Arg is 0 to assign client O symbol
                if ackArg == 0:
                    print('=' * 40)
                    print("You are O's!")
                    self.playerSymbol = 'O'
                    self.sock.send(tttp.acknowledge_packet(ackType, 0))
                    return True
                # Ack Arg is 1 to assign client X symbol
                elif ackArg == 1:
                    print('=' * 40)
                    print("You are X's")
                    self.playerSymbol = 'X'
                    self.sock.send(tttp.acknowledge_packet(ackType, 0))
                    return True

    # Waiting method until a message is received telling both clients are ready to start
    def wait_for_game_start(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['game start']:
                # Ack Arg is 0 when we are still waiting on the other client to ready up from server
                if ackArg == 0:
                    if not self.isReady:
                        self.isReady = True
                    # Send acknowledgement that client is waiting
                    self.sock.send(tttp.acknowledge_packet(ackType, 0))
                    return "waiting for player"
                # Ack Arg is 1 when both Clients are ready
                elif ackArg == 1:
                    self.isReady = True
                    print("Starting Game!")
                    print('=' * 40)
                    # Send acknowledgement to start game
                    self.sock.send(tttp.acknowledge_packet(ackType, 1))
                    return "starting game"

    # Waiting method until a message is received affirming to the client if the game is over
    def wait_for_game_end(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['game end']:
                # Ack Arg is 0 when the game is still in play
                if ackArg == 0:
                    self.sock.send(tttp.acknowledge_packet(ackType, 0))
                    return "game still in play"
                # Ack Arg is 1 when game has ended
                elif ackArg == 1:
                    self.sock.send(tttp.acknowledge_packet(ackType, 1))
                    return "game end"

    # Waiting method until a message is received telling the client it is their turn
    def wait_for_turn_ack(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['player turn']:
                # Ack Arg is 0 when it is not this Client's turn to position their symbol
                if ackArg == 0:
                    # Set player turn accordingly to switch symbols
                    if self.playerSymbol.lower() == 'x':
                        ttte.x_turn = False
                    else:
                        ttte.x_turn = True
                    self.sock.send(tttp.acknowledge_packet(ackType, 0))
                    return "not your turn"
                # Ack Arg is 1 when it is this client's turn to position their symbol
                elif ackArg == 1:
                    # Set player turn accordingly to switch symbols
                    if self.playerSymbol.lower() == 'x':
                        ttte.x_turn = True
                    else:
                        ttte.x_turn = False
                    self.sock.send(tttp.acknowledge_packet(ackType, 1))
                    return "your turn"

    # Waiting method until a message is received regarding the player's action move
    def wait_for_turn_action(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        # Acknowledgement for valid symbol placement
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['player move']:
                if 1 <= ackArg <= 9:
                    self.sock.send(tttp.acknowledge_packet(ackType, 1))
                    return "executed move"
                elif ackArg == 0:
                    # send packet for still waiting
                    pass
        # Received an error packet telling client that previous sent position for symbol is an invalid move
        elif op == tttp.TTT_OPCODES['error']:
            errType, errArg = tttp.unpack_error_packet(packet)
            if errType == tttp.TTT_OPCODES['player move']:
                if errArg == 0:
                    self.sock.send(tttp.acknowledge_packet(errType, 0))
                    print(f"Invalid move position! Try placing {self.playerSymbol} elsewhere.")
                    self.send_player_input_position()
                    return "unsuccessful"

    # Handles the player input action when it is their turn
    def send_player_input_position(self):
        position = 0
        # Check if player input is correct format
        validPosition = False
        while not validPosition:
            inputText = input()
            if len(inputText) == 1 and inputText.isdigit():
                validPosition = True
                position = int(inputText)
            else:
                print(f"Invalid Input. Input a number 1-9 to place {self.playerSymbol}.")
        # Send the correct format to the server
        self.sock.send(tttp.player_move_packet(position))

    def wait_for_board_update(self):
        packet = self.recv_message()
        op = tttp.get_opcode(packet)
        # If the received message is a syn acknowledge packet
        if op == tttp.TTT_OPCODES['syn acknowledge']:
            ackType, ackArg = tttp.unpack_syn_acknowledge_packet(packet)
            if ackType == tttp.TTT_OPCODES['update board']:
                # ackArg to tell that game is still in play
                if ackArg == 0:
                    # Acknowledge server update board message
                    self.sock.send(tttp.acknowledge_packet(tttp.TTT_OPCODES['update board'], 0))
                    # Update board symbol positions for client
                    print('=' * 40)
                    for i in range(9):
                        packet = self.recv_message()
                        boardOp = tttp.get_opcode(packet)
                        if boardOp == tttp.TTT_OPCODES['board acknowledge']:
                            position, symbol = tttp.unpack_board_acknowledge_packet(packet)
                            if symbol == 0:
                                ttte.board[position] = '-'
                            elif symbol == 1:
                                if ttte.board[position] == '-':
                                    ttte.turns += 1
                                ttte.board[position] = 'X'
                            elif symbol == 2:
                                if ttte.board[position] == '-':
                                    ttte.turns += 1
                                ttte.board[position] = 'O'
                            self.sock.send(tttp.acknowledge_packet(boardOp, position))
                    print("")
                    ttte.display_board()
                    return True
        else:
            return False


if __name__ == '__main__':
    port = 9001

    parser = argparse.ArgumentParser(description='Client')
    parser.add_argument('host', help='IP address of the server.')
    args = parser.parse_args()

    client = Client(args.host, port)
