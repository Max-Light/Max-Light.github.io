# Author: Maxwell Light
# Email: maxwell.light238@myci.csuci.edu
# Date: 03-05-21
# server.py - a simple threaded server

import argparse, socket, logging, threading, select
import TicTacToeEngine
import TicTacToeProtocol

# Comment out the line below to not print the INFO messages
logging.basicConfig(level=logging.INFO)
clientThreads = []
ttte = TicTacToeEngine.TicTacToeEngine()
tttp = TicTacToeProtocol.TTTProtocol()


def check_if_all_clients_ready():
    if len(clientThreads) > 1:
        if clientThreads[0].isReady and clientThreads[1].isReady:
            return True
    return False


def check_if_player_turn(symbol):
    if ttte.x_turn and symbol.lower() == 'x':
        return True
    elif not ttte.x_turn and symbol.lower() == 'o':
        return True
    else:
        return False


class ClientThread(threading.Thread):
    # Static field used to keep track of saved game in the case that the client forcibly leaves
    isGameInPlay = False

    def __init__(self, address, socket, thread_cond):
        threading.Thread.__init__(self)
        self.csock = socket
        self.address = address
        self.thread_cond = thread_cond
        self.isReady = False
        self.playerSymbol = '-'

    # Running thread
    def run(self):
        self.thread_cond.acquire()

        while True:
            self.read_message()
            continue

        # Disconnect client whenever thread has stopped running (useful when adding a quit protocol)
        self.csock.close()
        logging.info('Disconnected client.')

    # Wait and receive a message
    def recv_message(self):
        try:
            message = self.csock.recv(1024)
            if not message:
                raise EOFError('socket closed')
            return message
        except socket.error:
            # Remove client thread from list
            clientThreads.remove(self)
            # Release thread conditional object
            self.thread_cond.release()
            return bytearray(00)

    # Wait to receives any messages from the client on this thread
    def read_message(self):
        package = self.recv_message()
        if len(package) < 2:
            return
        # Get received opcode
        opcode = tttp.get_opcode(package)
        if opcode == tttp.TTT_OPCODES['player symbol']:
            self.assign_player_symbol(opcode)
        elif opcode == tttp.TTT_OPCODES['game start']:
            self.set_player_ready(opcode)
        elif opcode == tttp.TTT_OPCODES['game end']:
            self.is_game_over(opcode)
        elif opcode == tttp.TTT_OPCODES['player turn']:
            self.set_player_turn(opcode)
        elif opcode == tttp.TTT_OPCODES['player move']:
            self.execute_player_turn(opcode, tttp.unpack_move_packet(package))
        elif opcode == tttp.TTT_OPCODES['update board']:
            self.update_board(opcode)

    # Assign the player symbol (Called from the player symbol protocol)
    def assign_player_symbol(self, opcode):
        # if this is the first thread, then assign X to this player
        if self == clientThreads[0]:
            print(f"Assigning client {self.address} symbol X")
            self.playerSymbol = 'X'
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 1))
        # if this is the second thread, then assign O to this player
        elif self == clientThreads[1]:
            print(f"Assigning client {self.address} symbol O")
            self.playerSymbol = 'O'
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 0))
        # stall thread until it receives ack packet
        self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))

    # Set player to ready status
    def set_player_ready(self, opcode):
        # Set player to ready status
        if not self.isReady:
            print(f"Client {self.address} is ready!")
            self.isReady = True
        # When second client is ready, this condition is passed once to restart game on empty board
        if check_if_all_clients_ready() and not ClientThread.isGameInPlay:
            print("Creating empty board!")
            ttte.restart()
        # Keep sending ack packets to player that game is not ready
        while not check_if_all_clients_ready():
            # Ack Arg is 0 when not ready
            # Keep sending Ack packets when game is not ready
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 0))
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))
        self.start_game(opcode)

    # Send ack packet to player that game is ready
    def start_game(self, opcode):
        if ClientThread.isGameInPlay is False:
            ClientThread.isGameInPlay = True
        # Ack Arg is 1 when game is ready
        # Send Ack packet saying game is ready
        self.csock.send(tttp.syn_acknowledge_packet(opcode, 1))
        self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 1)))
        print(f"Ready to start game for client on {self.address}.")

    # Send ack packet to the client telling them if the game is over or not
    def is_game_over(self, opcode):
        # If the game is over, send affirming end game syn ack packet
        if ttte.is_game_over() != '-' or not self.isReady:
            # Once the game is over set both clients to not ready status
            if check_if_all_clients_ready():
                if clientThreads[0] is not None:
                    clientThreads[0].isReady = False
                if clientThreads[1] is not None:
                    clientThreads[1].isReady = False
                # Output message to server showing who won
                print('=' * 40)
                print("Game Over!")
                winner = ttte.is_game_over()
                if winner != 'T':
                    print(f"The Winner is {winner}!")
                else:
                    print("Draw!")
                print('=' * 40)
                ClientThread.isGameInPlay = False
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 1))
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 1)))
        # If the game is still in play, send still in play packet
        else:
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 0))
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))

    # Sets the player turn
    def set_player_turn(self, opcode):
        while not check_if_player_turn(self.playerSymbol):
            # Ack Arg is 0 when not player's turn
            self.csock.send(tttp.syn_acknowledge_packet(opcode, 0))
            # Wait for ack from client
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))
        # Ack Arg is 1 when it is player's turn
        self.csock.send(tttp.syn_acknowledge_packet(opcode, 1))
        self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 1)))
        print(f"It is client {self.address} turn")

    # Executes the player's request to move their symbol at the inputted position
    def execute_player_turn(self, opcode, position):
        print(f"Client is attempting to move {self.playerSymbol} at position {position}")
        # Inputted position is invalid
        if not ttte.is_move_valid(position):
            # Send error packet for invalid move
            self.csock.send(tttp.error_packet(opcode, 0))
            # wait for client to acknowledge error packet
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))
        # Inputted position is valid
        else:
            ttte.make_move(position)
            self.csock.send(tttp.syn_acknowledge_packet(opcode, position))
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 1)))

    def update_board(self, opcode):
        # Send updated symbol positions of board to client
        self.csock.send(tttp.syn_acknowledge_packet(opcode, 0))
        self.thread_cond.wait_for(lambda: (self.wait_for_ack(opcode, 0)))
        # send a total of 9 packets to client (9 packets for 9 symbol positions)
        for i in range(9):
            symbol = 0
            if ttte.board[i].lower() == 'x':
                symbol = 1
            elif ttte.board[i].lower() == 'o':
                symbol = 2
            self.csock.send(tttp.board_acknowledge_packet(i, symbol))
            self.thread_cond.wait_for(lambda: (self.wait_for_ack(tttp.TTT_OPCODES['board acknowledge'], i)))

    # Wait for the specific acknowledge packet corresponding to the previously received protocol
    # Very useful and less time consuming with lambda functions :)
    def wait_for_ack(self, ackType, ackArg):
        while True:
            packet = self.recv_message()
            if len(packet) < 2:
                continue
            opcode = tttp.get_opcode(packet)
            if opcode == tttp.TTT_OPCODES['acknowledge']:
                aType, aArg = tttp.unpack_acknowledge_packet(packet)
                if ackType == aType and ackArg == aArg:
                    return True


class Server:
    def __init__(self):
        # start serving (listening for clients)
        port = 9001
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('localhost', port))
        sock.listen(2)
        logging.info('Server: ' + str(sock.getsockname()) + ', is listening on port ' + str(port))

        while True:
            connectionToClient, socketAddress = sock.accept()
            # check if the maximum amount of clients has been reached
            if len(clientThreads) == 2:
                connectionToClient.close()

            logging.info(f'Client connected with address {socketAddress}.')
            # https://docs.python.org/3.8/library/threading.html#threading.Condition
            thread_cond = threading.Condition()
            clientThread = ClientThread(socketAddress, connectionToClient, thread_cond)
            # append thread to total threads
            if len(clientThreads) == 1:
                if clientThreads[0].playerSymbol.lower() == 'o':
                    clientThreads.insert(0, clientThread)
                else:
                    clientThreads.append(clientThread)
            else:
                clientThreads.append(clientThread)
            # Start client thread
            clientThread.start()
            continue

        sock.close()


if __name__ == '__main__':
    server = Server()
