# Author: Maxwell Light
# Email: maxwell.light238@myci.csuci.edu
# Date: 03-05-21
class TTTProtocol:
    # TTT Protocol Opcodes
    # Set as a dictionary in case of any additional protocols wanting to be added in order to save time and avoid confusion :)
    TTT_OPCODES = {
        'unknown': 0,
        'player symbol': 1,
        'game start': 2,
        'game end': 3,
        'player turn': 4,
        'player move': 5,
        'update board': 6,
        'acknowledge': 7,
        'syn acknowledge': 8,
        'board acknowledge': 9,
        'error': 10
    }

    # return byte packet containing player symbol assignment
    def player_symbol_request_packet(self):
        playerSymbol = bytearray()
        playerSymbol += self.TTT_OPCODES['player symbol'].to_bytes(2, "big")
        return playerSymbol

    # return byte packet containing game start
    def game_ready_to_start_packet(self):
        gameStart = bytearray()
        gameStart += self.TTT_OPCODES['game start'].to_bytes(2, "big")
        return gameStart

    # return byte packet containing game end condition packet
    def game_end_packet(self):
        gameEnd = bytearray()
        gameEnd += self.TTT_OPCODES['game end'].to_bytes(2, "big")
        return gameEnd

    # return byte packet containing player turn packet
    def player_turn_packet(self):
        playerTurn = bytearray()
        playerTurn += self.TTT_OPCODES['player turn'].to_bytes(2, "big")
        return playerTurn

    # return byte packet containing player move
    def player_move_packet(self, position):
        playerMove = bytearray()
        playerMove += self.TTT_OPCODES['player move'].to_bytes(2, "big")
        playerMove += position.to_bytes(1, "big")
        return playerMove

    # return byte packet containing update board request
    def request_updated_board(self):
        updateBoard = bytearray()
        updateBoard += self.TTT_OPCODES['update board'].to_bytes(2, "big")
        return updateBoard

    # return acknowledgement byte packet to receiver to ensure that information has been sent
    def acknowledge_packet(self, ackType, ackArg):
        ack = bytearray()
        ack += self.TTT_OPCODES['acknowledge'].to_bytes(2, "big")
        ack += ackType.to_bytes(2, "big")
        ack += ackArg.to_bytes(2, "big")
        return ack

    # return syn acknowledgement byte packet to sender to ensure information has been sent
    def syn_acknowledge_packet(self, synAckType, synAckArg):
        ack = bytearray()
        ack += self.TTT_OPCODES['syn acknowledge'].to_bytes(2, "big")
        ack += synAckType.to_bytes(2, "big")
        ack += synAckArg.to_bytes(2, "big")
        return ack

    # return acknowledge board byte packet for updates on board to client
    def board_acknowledge_packet(self, position, symbol):
        ack = bytearray()
        ack += self.TTT_OPCODES['board acknowledge'].to_bytes(2, "big")
        ack += position.to_bytes(2, "big")
        ack += symbol.to_bytes(2, "big")
        return ack

    # return error byte packet containing error type and error arg
    def error_packet(self, errType, errArg):
        err = bytearray()
        err += self.TTT_OPCODES['error'].to_bytes(2, "big")
        err += errType.to_bytes(2, "big")
        err += errArg.to_bytes(2, "big")
        return err

    # get opcode from packet
    def get_opcode(self, packet):
        opcode = self.decodeInt(packet[0:2])
        return opcode

    # return contents of acknowledge packet (tuple)
    def unpack_acknowledge_packet(self, packet):
        return self.decodeInt(packet[2:4]), self.decodeInt(packet[4:6])

    # return contents of syn acknowledge packet (tuple)
    def unpack_syn_acknowledge_packet(self, packet):
        return self.decodeInt(packet[2:4]), self.decodeInt(packet[4:6])

    # return contents of board acknowledge packet (tuple)
    def unpack_board_acknowledge_packet(self, packet):
        return self.decodeInt(packet[2:4]), self.decodeInt(packet[4:6])

    # return contents of player move packet with position
    def unpack_move_packet(self, packet):
        return self.decodeInt(packet[2:3])

    # return contents of error packet (tuple)
    def unpack_error_packet(self, packet):
        return self.decodeInt(packet[2:4]), self.decodeInt(packet[4:6])

    # return the corresponding integer from the byte input
    def decodeInt(self, bytes):
        return int.from_bytes(bytes, "big")
